Example 1
---------------------------
.. literalinclude:: ../examples/qwiic_relay_ex1.py
    :caption: examples/qwiic_relay_ex1.py
    :linenos:

