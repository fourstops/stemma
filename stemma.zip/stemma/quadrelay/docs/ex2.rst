Example 2
-----------------------------------
.. literalinclude:: ../examples/qwiic_relay_ex2.py
    :caption: examples/qwiic_relay_ex2.py
    :linenos:
