Qwiic Relay Py
==========================

This Python package is meant to control all of the different available SparkFun Relays. These include the Qwiic Single Relay, Qwiic Quad Relay, Qwiic Dual Solid-State Relay and Qwiic Quad Solid-State Relay using the Qwiic-i2c package from SparkFun