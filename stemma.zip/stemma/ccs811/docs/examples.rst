Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/ccs811_simpletest.py
    :caption: examples/ccs811_simpletest.py
    :linenos:
