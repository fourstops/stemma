Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/sgp40_simpletest.py
    :caption: examples/sgp40_simpletest.py
    :linenos:
