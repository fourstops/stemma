
.. If you created a package, create one automodule per module in the package.

.. automodule:: adafruit_apds9960.apds9960
   :members:

.. automodule:: adafruit_apds9960.colorutility
   :members:
