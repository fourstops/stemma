Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/bmp3xx_simpletest.py
    :caption: examples/bmp3xx_simpletest.py
    :linenos:
